import test from 'node:test';
import assert from 'node:assert/strict';
test('synthetic canonical candidate', () => assert.equal(2 + 2, 4));
